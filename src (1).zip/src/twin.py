"""
twin.py
=======
Digital Twin simulation engine for Smart Building Energy Monitoring.

A Digital Twin is a virtual software representation of a physical asset
(the building) that runs in parallel with real-world sensor streams.

Capabilities:
1. Ingests live telemetry (temperature, humidity, occupancy, actual energy).
2. Maintains historical state buffer to compute real-time lag and rolling features.
3. Produces real-time energy forecasts via the trained Random Forest model.
4. Detects thermodynamic and behavioral anomalies using the 3-Sigma residual threshold:
       |Actual - Predicted| > (Mean + 3 * Std)
5. Simulates live row-by-row streaming for dashboards.
6. Powers 'What-If' scenario forecasting (counterfactual building simulations).
"""

import os
import joblib
import pandas as pd
import numpy as np
from typing import Dict, Any, Generator, Optional, List


class BuildingDigitalTwin:
    """
    Virtual representation of the building's thermodynamic and electrical behavior.
    """

    def __init__(self, model_path: str = "models/random_forest_energy_model.joblib"):
        """
        Loads the trained Random Forest model bundle and sets up twin state buffers.
        """
        if not os.path.exists(model_path):
            raise FileNotFoundError(
                f"Model file not found at {model_path}. Please run 'python src/train.py' first!"
            )

        print(f"Loading Digital Twin brain from {model_path}...")
        self.bundle = joblib.load(model_path)
        self.model = self.bundle["model"]
        self.baseline_model = self.bundle.get("baseline_model", None)
        self.feature_names = self.bundle["feature_names"]
        self.anomaly_params = self.bundle["anomaly_params"]
        self.threshold_3sigma = self.anomaly_params["threshold_3sigma"]
        self.residual_mean = self.anomaly_params["residual_mean"]
        self.residual_std = self.anomaly_params["residual_std"]

        # Circular/history buffer to maintain past 48 hours for autoregressive features
        self.energy_history: List[float] = []
        self.timestamp_history: List[pd.Timestamp] = []

    def initialize_history(self, warm_up_df: pd.DataFrame):
        """
        Pre-seeds the twin's history buffer with initial rows so that
        the first live stream row can immediately compute 1h and 24h lags.
        """
        # Take the most recent 48 rows
        recent = warm_up_df.tail(48)
        self.energy_history = list(recent["energy"].values)
        self.timestamp_history = list(pd.to_datetime(recent["timestamp"]).values)

    def process_telemetry(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """
        Processes a single live sensor reading from the physical building.

        Parameters:
        -----------
        row : dict with keys:
            'timestamp'   : datetime or string
            'temperature' : float (°C)
            'humidity'    : float (%)
            'occupancy'   : int/float (number of occupants)
            'energy'      : float (actual measured energy in kWh)

        Returns:
        --------
        dict:
            Comprehensive Digital Twin status including predicted energy,
            residual, anomaly flag, and severity score.
        """
        ts = pd.to_datetime(row["timestamp"])
        temp = float(row["temperature"])
        humid = float(row["humidity"])
        occ = int(row["occupancy"])
        actual_energy = float(row["energy"])

        # 1. Compute time-derived features
        hour = ts.hour
        day_of_week = ts.dayofweek
        is_weekend = 1 if day_of_week >= 5 else 0

        # 2. Extract lag and rolling features from twin history buffer
        if len(self.energy_history) >= 24:
            lag_1h = float(self.energy_history[-1])
            lag_24h = float(self.energy_history[-24])
            rolling_24h = float(np.mean(self.energy_history[-24:]))
        elif len(self.energy_history) > 0:
            lag_1h = float(self.energy_history[-1])
            lag_24h = float(self.energy_history[0])
            rolling_24h = float(np.mean(self.energy_history))
        else:
            # If no history yet, use the current energy as cold-start fallback
            lag_1h = actual_energy
            lag_24h = actual_energy
            rolling_24h = actual_energy

        # 3. Assemble feature vector in exact order expected by the model
        feature_dict = {
            "temperature": temp,
            "humidity": humid,
            "occupancy": occ,
            "hour": hour,
            "day_of_week": day_of_week,
            "is_weekend": is_weekend,
            "energy_lag_1h": lag_1h,
            "energy_lag_24h": lag_24h,
            "energy_rolling_mean_24h": rolling_24h,
        }
        X_live = pd.DataFrame([feature_dict])[self.feature_names]

        # 4. Generate Digital Twin forecast
        predicted_energy = float(self.model.predict(X_live)[0])
        predicted_energy = max(0.0, round(predicted_energy, 3))

        # 5. Anomaly Detection Logic: 3-Sigma Rule on Residuals
        residual = round(actual_energy - predicted_energy, 3)
        abs_deviation = round(abs(residual), 3)

        # Flag an anomaly if deviation exceeds mean + 3*std
        is_anomaly = bool(abs_deviation > self.threshold_3sigma)

        # Compute Z-score / severity of the deviation
        z_score = round(
            (abs_deviation - self.residual_mean) / (self.residual_std + 1e-6), 2
        )

        anomaly_type = "NORMAL"
        diagnosis = "Building operating within nominal thermodynamic bounds."
        if is_anomaly:
            if residual > 0:
                anomaly_type = "SURGE_ANOMALY"
                diagnosis = (
                    f"Power surge detected (+{residual:.2f} kWh above expected). "
                    "Suspected: HVAC chiller strain, equipment left on, or unexpected thermal load."
                )
            else:
                anomaly_type = "DROP_ANOMALY"
                diagnosis = (
                    f"Unexpected low draw detected ({residual:.2f} kWh below expected). "
                    "Suspected: Subsystem trip, power outage, or sensor disconnection."
                )

        # 6. Update history buffer
        self.energy_history.append(actual_energy)
        self.timestamp_history.append(ts)
        # Keep history capped at 168 hours (1 week) to conserve memory
        if len(self.energy_history) > 168:
            self.energy_history.pop(0)
            self.timestamp_history.pop(0)

        # 7. Return complete twin telemetry state
        return {
            "timestamp": str(ts),
            "temperature": temp,
            "humidity": humid,
            "occupancy": occ,
            "actual_energy": actual_energy,
            "predicted_energy": predicted_energy,
            "residual": residual,
            "abs_deviation": abs_deviation,
            "threshold_3sigma": round(self.threshold_3sigma, 3),
            "is_anomaly": is_anomaly,
            "anomaly_type": anomaly_type,
            "z_score": z_score,
            "diagnosis": diagnosis,
        }

    def simulate_stream(
        self, stream_df: pd.DataFrame
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Simulates an incoming live sensor data stream row-by-row.
        Yields Digital Twin status objects for each time step.
        """
        for _, row in stream_df.iterrows():
            reading = {
                "timestamp": row["timestamp"],
                "temperature": row["temperature"],
                "humidity": row["humidity"],
                "occupancy": row["occupancy"],
                "energy": row["energy"],
            }
            yield self.process_telemetry(reading)

    def what_if_simulation(
        self,
        temperature: float,
        humidity: float,
        occupancy: int,
        hour: int,
        is_weekend: int,
        day_of_week: Optional[int] = None,
        base_energy_reference: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Runs a What-If counterfactual scenario on the Digital Twin.

        Allows building managers to explore scenarios such as:
        - "What if heatwave raises outdoor temp to 35°C?"
        - "What if we mandate work-from-home on Fridays (occupancy = 0)?"
        - "What if we shift working hours?"
        """
        if day_of_week is None:
            day_of_week = 5 if is_weekend else 2  # Default to Wednesday or Saturday

        # Use recent rolling energy or a representative default
        if base_energy_reference is not None:
            ref_energy = base_energy_reference
        elif len(self.energy_history) > 0:
            ref_energy = float(np.mean(self.energy_history[-24:]))
        else:
            ref_energy = 0.6  # Default kWh

        feature_dict = {
            "temperature": float(temperature),
            "humidity": float(humidity),
            "occupancy": int(occupancy),
            "hour": int(hour),
            "day_of_week": int(day_of_week),
            "is_weekend": int(is_weekend),
            "energy_lag_1h": ref_energy,
            "energy_lag_24h": ref_energy,
            "energy_rolling_mean_24h": ref_energy,
        }
        X_whatif = pd.DataFrame([feature_dict])[self.feature_names]
        predicted_energy = float(self.model.predict(X_whatif)[0])
        predicted_energy = max(0.0, round(predicted_energy, 3))

        # Baseline comparison if available
        baseline_pred = None
        if self.baseline_model is not None:
            baseline_pred = round(float(self.baseline_model.predict(X_whatif)[0]), 3)

        return {
            "scenario_inputs": feature_dict,
            "predicted_energy": predicted_energy,
            "baseline_predicted_energy": baseline_pred,
            "estimated_hourly_cost_usd": round(predicted_energy * 0.18, 3),  # ~$0.18/kWh
            "estimated_co2_kg": round(predicted_energy * 0.42, 3),  # ~0.42 kg CO2/kWh
        }


if __name__ == "__main__":
    print("Testing twin module...")
    # Test with dummy or saved model if ready
    try:
        twin = BuildingDigitalTwin()
        test_reading = {
            "timestamp": "2024-06-01 14:00:00",
            "temperature": 28.5,
            "humidity": 65.0,
            "occupancy": 45,
            "energy": 0.85,
        }
        result = twin.process_telemetry(test_reading)
        print("Telemetry processed successfully:", result)
        
        what_if = twin.what_if_simulation(
            temperature=35.0, humidity=50.0, occupancy=80, hour=14, is_weekend=0
        )
        print("What-If Result:", what_if)
    except Exception as e:
        print("Twin initialized after training finishes:", e)
