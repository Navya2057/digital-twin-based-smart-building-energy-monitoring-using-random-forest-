"""
train.py
========
Model training, hyperparameter optimization, and evaluation pipeline for
the Smart Building Energy Monitoring Digital Twin.

Steps:
1. Loads cleaned data and generates lag/temporal features.
2. Performs time-based train/test split.
3. Trains a Baseline Linear Regression model.
4. Tunes and trains a Random Forest Regressor using TimeSeriesSplit & RandomizedSearchCV.
5. Evaluates both models using MAE, RMSE, and R².
6. Computes 3-Sigma residual thresholds for Digital Twin anomaly detection.
7. Saves the trained model bundle using joblib.
"""

import os
import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import RandomizedSearchCV, TimeSeriesSplit
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from preprocess import load_or_generate_data, clean_data
from features import create_features, time_based_train_test_split, FEATURE_COLUMNS, TARGET_COLUMN


def evaluate_predictions(y_true: pd.Series, y_pred: np.ndarray, model_name: str = "Model") -> dict:
    """
    Computes standard regression evaluation metrics:
    - MAE: Mean Absolute Error (average deviation in kWh)
    - RMSE: Root Mean Squared Error (penalizes large outlier mistakes)
    - R²: Coefficient of Determination (variance explained by model, 1.0 is perfect)
    """
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    
    print(f"\n[{model_name} Performance on Test Set]")
    print(f"  MAE:  {mae:.4f} kWh")
    print(f"  RMSE: {rmse:.4f} kWh")
    print(f"  R²:   {r2:.4f} ({r2*100:.2f}% variance explained)")
    
    return {"mae": float(mae), "rmse": float(rmse), "r2": float(r2)}


def train_baseline_model(X_train: pd.DataFrame, y_train: pd.Series) -> LinearRegression:
    """
    Trains a simple Linear Regression model as an interpretable baseline.
    """
    print("\nTraining Baseline Linear Regression model...")
    lr = LinearRegression()
    lr.fit(X_train, y_train)
    return lr


def train_random_forest(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    n_iter: int = 10,
    random_state: int = 42
) -> RandomForestRegressor:
    """
    Trains a Random Forest Regressor with hyperparameter tuning via RandomizedSearchCV.
    Uses TimeSeriesSplit to avoid lookahead leakage during cross-validation.
    """
    print(f"\nHyperparameter tuning for Random Forest ({n_iter} iterations with TimeSeriesSplit)...")
    
    param_distributions = {
        "n_estimators": [50, 100, 150, 200],
        "max_depth": [6, 10, 15, 20, None],
        "min_samples_split": [2, 5, 10],
        "min_samples_leaf": [1, 2, 4],
        "max_features": ["sqrt", 1.0]
    }
    
    base_rf = RandomForestRegressor(random_state=random_state, n_jobs=1)
    
    # TimeSeriesSplit ensures CV folds respect time sequence (folds 1->2, 1+2->3, etc.)
    tscv = TimeSeriesSplit(n_splits=3)
    
    search = RandomizedSearchCV(
        estimator=base_rf,
        param_distributions=param_distributions,
        n_iter=n_iter,
        cv=tscv,
        scoring="neg_mean_absolute_error",
        random_state=random_state,
        n_jobs=1,
        verbose=1
    )
    
    search.fit(X_train, y_train)
    print(f"Best parameters found: {search.best_params_}")
    return search.best_estimator_, search.best_params_


def calculate_anomaly_thresholds(y_true: pd.Series, y_pred: np.ndarray) -> dict:
    """
    Calculates statistical parameters on prediction residuals:
    residual = actual - predicted
    
    In the Digital Twin, an anomaly is flagged when:
    |residual| > residual_mean + 3 * residual_std (3-Sigma Rule)
    """
    residuals = y_true.values - y_pred
    abs_residuals = np.abs(residuals)
    
    res_mean = float(np.mean(abs_residuals))
    res_std = float(np.std(abs_residuals))
    threshold_3sigma = float(res_mean + 3.0 * res_std)
    
    print(f"\n[Digital Twin Anomaly Parameters]")
    print(f"  Residual Absolute Mean: {res_mean:.4f} kWh")
    print(f"  Residual Absolute Std:  {res_std:.4f} kWh")
    print(f"  3-Sigma Anomaly Cutoff: {threshold_3sigma:.4f} kWh")
    
    return {
        "residual_mean": res_mean,
        "residual_std": res_std,
        "threshold_3sigma": threshold_3sigma
    }


def run_training_pipeline(
    data_path: str = "data/building_energy.csv",
    model_output_path: str = "models/random_forest_energy_model.joblib",
    test_size: float = 0.20
):
    """
    Executes the complete training, evaluation, and serialization pipeline.
    """
    print("=" * 60)
    print("DIGITAL TWIN SMART BUILDING - MODEL TRAINING PIPELINE")
    print("=" * 60)
    
    # 1. Load and clean data
    raw_df = load_or_generate_data(data_path)
    cleaned_df = clean_data(raw_df)
    
    # 2. Engineer features
    print("\nEngineering features (lags, rolling averages, calendar)...")
    featured_df = create_features(cleaned_df)
    
    # 3. Time-based train/test split
    print(f"\nPerforming chronological time-based split (test_size={test_size})...")
    X_train, y_train, X_test, y_test, feature_names, train_df, test_df = time_based_train_test_split(
        featured_df, test_size=test_size
    )
    print(f"Training samples: {len(X_train)} | Testing samples: {len(X_test)}")
    
    # 4. Baseline Linear Regression
    baseline_model = train_baseline_model(X_train, y_train)
    y_pred_baseline = baseline_model.predict(X_test)
    baseline_metrics = evaluate_predictions(y_test, y_pred_baseline, model_name="Baseline Linear Regression")
    
    # 5. Tuned Random Forest Regressor
    best_rf, best_params = train_random_forest(X_train, y_train, n_iter=10)
    y_pred_rf = best_rf.predict(X_test)
    rf_metrics = evaluate_predictions(y_test, y_pred_rf, model_name="Tuned Random Forest Regressor")
    
    # Compare models
    mae_diff = (baseline_metrics["mae"] - rf_metrics["mae"]) / baseline_metrics["mae"] * 100
    print(f"\n>>> Random Forest MAE improvement over Baseline: {mae_diff:.2f}% <<<")
    
    # 6. Compute Anomaly Detection Thresholds on training residuals (healthy baseline)
    y_train_pred = best_rf.predict(X_train)
    anomaly_params = calculate_anomaly_thresholds(y_train, y_train_pred)
    
    # 7. Extract Feature Importances
    importances = best_rf.feature_importances_
    feat_imp_df = pd.DataFrame({
        "feature": feature_names,
        "importance": importances
    }).sort_values(by="importance", ascending=False)
    
    print("\n[Feature Importances]")
    for idx, row in feat_imp_df.iterrows():
        print(f"  {row['feature']:<25}: {row['importance']:.4f}")
        
    # 8. Save Test Predictions for Digital Twin Simulation and Streamlit App
    test_eval_df = test_df.copy()
    test_eval_df["predicted_energy"] = np.round(y_pred_rf, 2)
    test_eval_df["residual"] = np.round(test_eval_df["energy"] - test_eval_df["predicted_energy"], 2)
    test_eval_df["abs_deviation"] = np.abs(test_eval_df["residual"])
    test_eval_df["is_anomaly"] = test_eval_df["abs_deviation"] > anomaly_params["threshold_3sigma"]
    
    os.makedirs("data", exist_ok=True)
    test_eval_path = "data/test_evaluation_stream.csv"
    test_eval_df.to_csv(test_eval_path, index=False)
    print(f"\nSaved test evaluation stream to {test_eval_path} ({test_eval_df['is_anomaly'].sum()} anomalies flagged)")
    
    # 9. Save Model Bundle with joblib
    os.makedirs(os.path.dirname(model_output_path), exist_ok=True)
    bundle = {
        "model": best_rf,
        "baseline_model": baseline_model,
        "feature_names": feature_names,
        "target_name": TARGET_COLUMN,
        "metrics": {
            "baseline": baseline_metrics,
            "random_forest": rf_metrics
        },
        "anomaly_params": anomaly_params,
        "feature_importances": feat_imp_df.to_dict(orient="records"),
        "best_params": best_params
    }
    
    joblib.dump(bundle, model_output_path)
    print(f"Saved complete model bundle to {model_output_path}")
    print("\nTraining pipeline completed successfully!")


if __name__ == "__main__":
    run_training_pipeline()
