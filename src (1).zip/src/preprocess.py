"""
preprocess.py
==============
Data loading, cleaning, synthetic generation, and exploratory data analysis (EDA)
for the Smart Building Digital Twin project.

Columns required:
- timestamp: DateTime of the measurement
- temperature: Ambient/outdoor temperature in degrees Celsius (°C)
- humidity: Relative humidity percentage (%)
- occupancy: Number of people in the building
- energy: Total building energy consumed in kilowatt-hours (kWh)
"""

import os
import urllib.request
import pandas as pd
import numpy as np


def generate_synthetic_building_data(n_days: int = 90, random_seed: int = 42) -> pd.DataFrame:
    """
    Generate realistic, physics-grounded synthetic smart building data.
    
    Why synthetic?
    If offline or if remote dataset download is unavailable, this guarantees a
    reproducible, high-quality dataset following real thermodynamic and human occupancy patterns:
    - Diurnal temperature cycles (hotter afternoon, cooler night)
    - Weekday vs. weekend human occupancy schedules
    - HVAC cooling/heating demand proportional to temperature deviation from 22°C
    - Base electrical load (servers, refrigeration, standby circuits)
    - Occasional realistic anomalies (e.g., equipment malfunction, stuck HVAC, off-hours spikes)
    """
    np.random.seed(random_seed)
    
    # 1. Hourly timestamps over n_days
    start_time = pd.Timestamp("2024-01-01 00:00:00")
    total_hours = n_days * 24
    timestamps = pd.date_range(start=start_time, periods=total_hours, freq="h")
    
    hours = timestamps.hour.values
    days_of_week = timestamps.dayofweek.values  # 0=Monday, 6=Sunday
    is_weekend = (days_of_week >= 5).astype(int)
    
    # 2. Temperature simulation (°C): seasonal base + diurnal wave + random weather fluctuations
    # Diurnal wave peaks around 14:00 (hour 14), lowest around 04:00
    diurnal_temp = 7.0 * np.sin(2 * np.pi * (hours - 8) / 24)
    # Slow multi-day weather wave (weather fronts passing)
    weather_fronts = 4.0 * np.sin(2 * np.pi * np.arange(total_hours) / (24 * 7))
    base_temp = 20.0
    noise_temp = np.random.normal(0, 1.2, size=total_hours)
    temperature = np.round(base_temp + diurnal_temp + weather_fronts + noise_temp, 2)
    
    # 3. Humidity simulation (%): inversely related to temperature + random noise
    base_humidity = 55.0
    diurnal_humidity = -12.0 * np.sin(2 * np.pi * (hours - 8) / 24)
    noise_humidity = np.random.normal(0, 3.0, size=total_hours)
    humidity = np.clip(np.round(base_humidity + diurnal_humidity + noise_humidity, 2), 20.0, 95.0)
    
    # 4. Occupancy simulation (number of occupants in commercial building)
    occupancy = np.zeros(total_hours, dtype=int)
    for i in range(total_hours):
        h = hours[i]
        wknd = is_weekend[i]
        if wknd:
            # Low occupancy on weekends (security, cleaners, occasional weekend workers)
            if 9 <= h <= 17:
                occupancy[i] = int(np.random.poisson(lam=4))
            else:
                occupancy[i] = int(np.random.poisson(lam=1))
        else:
            # Commercial working hours: 08:00 - 18:00
            if 8 <= h <= 18:
                # Bell curve centered around 13:00 (peak lunch/work hours)
                peak_factor = np.exp(-0.5 * ((h - 13) / 2.5) ** 2)
                mean_occ = 15 + 75 * peak_factor
                occupancy[i] = max(5, int(np.random.normal(mean_occ, 6)))
            elif (6 <= h < 8) or (18 < h <= 21):
                # Transition hours (early arrivals, late departures)
                occupancy[i] = max(1, int(np.random.normal(12, 3)))
            else:
                # Night hours (night shift, security)
                occupancy[i] = max(0, int(np.random.poisson(lam=2)))
    
    # 5. Energy consumption simulation (kWh)
    # Physical components:
    # a) Base electrical load (constant servers, safety lighting, IT backbone) ~ 15 kWh
    base_load = 15.0
    
    # b) Occupancy driven load (computers, task lights, appliances ~ 0.25 kWh per person)
    occupant_load = occupancy * 0.28
    
    # c) HVAC load: Energy required to heat or cool towards 22°C comfort setpoint
    # Non-linear thermal demand: higher outside temp means massive chiller load
    cooling_delta = np.maximum(0, temperature - 22.0)
    heating_delta = np.maximum(0, 18.0 - temperature)
    hvac_load = (cooling_delta * 2.2) + (heating_delta * 1.8)
    
    # Small equipment noise
    noise_energy = np.random.normal(0, 1.0, size=total_hours)
    
    energy = base_load + occupant_load + hvac_load + noise_energy
    
    # 6. Inject realistic anomalies for testing the Digital Twin anomaly detector
    # e.g., stuck HVAC chiller during a warm day, unexpected weekend power surge, sudden spike
    anomaly_indices = np.random.choice(
        np.arange(int(total_hours * 0.2), total_hours),
        size=int(total_hours * 0.02),  # ~2% anomaly rate
        replace=False
    )
    for idx in anomaly_indices:
        # Either unexpected surge (+18 to +35 kWh) or unexpected drop (-10 kWh)
        direction = np.random.choice([1, 1, 1, -1])  # Mostly excess spikes
        if direction == 1:
            energy[idx] += np.random.uniform(18.0, 35.0)
        else:
            energy[idx] = max(5.0, energy[idx] - np.random.uniform(10.0, 15.0))
            
    energy = np.round(np.clip(energy, 2.0, 120.0), 2)
    
    df = pd.DataFrame({
        "timestamp": timestamps,
        "temperature": temperature,
        "humidity": humidity,
        "occupancy": occupancy,
        "energy": energy
    })
    
    return df


def download_uci_dataset(dest_path: str = "data/energydata_complete.csv") -> pd.DataFrame:
    """
    Attempts to download the UCI Appliances Energy Prediction dataset.
    Falls back to generating synthetic data if the URL is unreachable.
    """
    url = "https://raw.githubusercontent.com/LuisM78/Appliances-energy-prediction-data/master/energydata_complete.csv"
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    
    print(f"Attempting to download UCI Appliances dataset from {url}...")
    try:
        import socket
        socket.setdefaulttimeout(5)
        urllib.request.urlretrieve(url, dest_path)
        print("Successfully downloaded UCI dataset.")
        raw_df = pd.read_csv(dest_path)
        
        # Transform UCI dataset to match our standard project schema:
        # timestamp, temperature, humidity, occupancy, energy (kWh)
        raw_df["timestamp"] = pd.to_datetime(raw_df["date"])
        # Aggregate 10-minute records to hourly records
        raw_df.set_index("timestamp", inplace=True)
        
        hourly_df = pd.DataFrame()
        hourly_df["energy"] = (raw_df["Appliances"] + raw_df["lights"]).resample("1h").sum() / 1000.0  # Wh to kWh
        hourly_df["temperature"] = raw_df["T_out"].resample("1h").mean()
        hourly_df["humidity"] = raw_df["RH_out"].resample("1h").mean()
        
        # UCI dataset does not have people count; synthesize realistic occupancy profile
        hours = hourly_df.index.hour
        days = hourly_df.index.dayofweek
        is_wknd = (days >= 5)
        # Approximate occupancy from lights & working hours
        occ = []
        for h, wknd in zip(hours, is_wknd):
            if wknd:
                occ.append(int(np.random.poisson(2)))
            elif 8 <= h <= 18:
                occ.append(int(np.random.normal(45, 10)))
            else:
                occ.append(int(np.random.poisson(3)))
        hourly_df["occupancy"] = occ
        hourly_df.reset_index(inplace=True)
        
        # Round values
        hourly_df["energy"] = hourly_df["energy"].round(2)
        hourly_df["temperature"] = hourly_df["temperature"].round(2)
        hourly_df["humidity"] = hourly_df["humidity"].round(2)
        
        return hourly_df[["timestamp", "temperature", "humidity", "occupancy", "energy"]]
    except Exception as e:
        print(f"UCI download not available ({e}). Falling back to high-fidelity synthetic building data.")
        return generate_synthetic_building_data()


def load_or_generate_data(file_path: str = "data/building_energy.csv", n_days: int = 90) -> pd.DataFrame:
    """
    High-level entry point to load clean building data.
    If the file exists, it loads it.
    If not, it creates it and saves it for subsequent fast access.
    """
    if os.path.exists(file_path):
        print(f"Loading existing dataset from {file_path}")
        df = pd.read_csv(file_path)
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        return df

    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    
    # Try UCI download first; fall back to synthetic
    try:
        df = download_uci_dataset()
    except Exception:
        df = generate_synthetic_building_data(n_days=n_days)
        
    df.to_csv(file_path, index=False)
    print(f"Saved dataset with {len(df)} records to {file_path}")
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Inspects and cleans the dataframe:
    - Verifies timestamp datetime conversion
    - Sorts chronologically
    - Drops duplicates
    - Imputes missing values via linear time interpolation
    - Verifies non-negative energy values
    """
    df = df.copy()
    
    # 1. Datetime check
    if not pd.api.types.is_datetime64_any_dtype(df["timestamp"]):
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        
    # 2. Sort chronologically
    df.sort_values(by="timestamp", inplace=True)
    
    # 3. Drop duplicate timestamps
    df.drop_duplicates(subset=["timestamp"], keep="first", inplace=True)
    
    # 4. Handle missing values
    missing_count = df.isnull().sum().sum()
    if missing_count > 0:
        print(f"Found {missing_count} missing values. Performing forward/backward interpolation...")
        df.interpolate(method="linear", inplace=True)
        df.bfill(inplace=True)
        df.ffill(inplace=True)
        
    # 5. Sanity checks (energy cannot be negative)
    df["energy"] = df["energy"].clip(lower=0.0)
    df["occupancy"] = df["occupancy"].clip(lower=0).astype(int)
    
    df.reset_index(drop=True, inplace=True)
    return df


def run_eda_summary(df: pd.DataFrame) -> dict:
    """
    Computes key exploratory data analysis metrics:
    - Descriptive statistics
    - Hourly average energy consumption
    - Day-of-week average energy consumption
    - Correlation matrix
    """
    temp_df = df.copy()
    temp_df["hour"] = temp_df["timestamp"].dt.hour
    temp_df["day_name"] = temp_df["timestamp"].dt.day_name()
    
    hourly_avg = temp_df.groupby("hour")["energy"].mean().to_dict()
    daily_avg = temp_df.groupby("day_name")["energy"].mean().to_dict()
    corr_matrix = temp_df[["temperature", "humidity", "occupancy", "energy"]].corr()
    
    summary = {
        "num_records": len(df),
        "start_date": str(df["timestamp"].min()),
        "end_date": str(df["timestamp"].max()),
        "energy_stats": df["energy"].describe().to_dict(),
        "hourly_avg": hourly_avg,
        "daily_avg": daily_avg,
        "correlation": corr_matrix.round(3).to_dict()
    }
    return summary


if __name__ == "__main__":
    # Test script standalone
    print("Testing data pipeline...")
    data = load_or_generate_data()
    cleaned = clean_data(data)
    eda = run_eda_summary(cleaned)
    print("Cleaned data shape:", cleaned.shape)
    print("Energy mean:", cleaned['energy'].mean(), "kWh")
    print("Correlations with energy:\n", cleaned[["temperature", "humidity", "occupancy", "energy"]].corr()['energy'])
