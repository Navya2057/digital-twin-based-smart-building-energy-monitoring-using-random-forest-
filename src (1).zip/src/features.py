"""
features.py
===========
Feature engineering and time-based dataset splitting for the
Smart Building Energy Monitoring Digital Twin.

Includes:
1. Cyclical and calendar features: hour, day of week, weekend flag
2. Autoregressive lag features: lag-1h, lag-24h
3. Moving statistics: 24-hour rolling mean (leakage-free)
4. Chronological time-series split (strictly no random shuffling)
"""

import pandas as pd
import numpy as np
from typing import Tuple, List


FEATURE_COLUMNS = [
    "temperature",
    "humidity",
    "occupancy",
    "hour",
    "day_of_week",
    "is_weekend",
    "energy_lag_1h",
    "energy_lag_24h",
    "energy_rolling_mean_24h",
]

TARGET_COLUMN = "energy"


def create_features(df: pd.DataFrame, drop_na: bool = True) -> pd.DataFrame:
    """
    Transforms raw telemetry into a rich feature set for time-series forecasting.

    Parameters:
    -----------
    df : pd.DataFrame
        Input data containing ['timestamp', 'temperature', 'humidity', 'occupancy', 'energy'].
    drop_na : bool
        Whether to drop initial rows with NaNs resulting from lag calculations.

    Returns:
    --------
    pd.DataFrame
        DataFrame with engineered features.
    """
    data = df.copy()

    # Ensure timestamp is datetime and sort chronologically
    if not pd.api.types.is_datetime64_any_dtype(data["timestamp"]):
        data["timestamp"] = pd.to_datetime(data["timestamp"])
    data.sort_values("timestamp", inplace=True)
    data.reset_index(drop=True, inplace=True)

    # 1. Calendar / Temporal Features
    # Buildings have strong daily rhythms (HVAC schedules, lights, work hours)
    data["hour"] = data["timestamp"].dt.hour
    data["day_of_week"] = data["timestamp"].dt.dayofweek  # 0 = Monday, 6 = Sunday
    data["is_weekend"] = (data["day_of_week"] >= 5).astype(int)

    # 2. Autoregressive Lag Features
    # Energy from 1 hour ago captures short-term persistence/momentum
    data["energy_lag_1h"] = data["energy"].shift(1)

    # Energy from 24 hours ago captures daily periodicity (same hour yesterday)
    data["energy_lag_24h"] = data["energy"].shift(24)

    # 3. Rolling Statistics
    # 24-hour moving average captures baseline level and multi-day trend.
    # CRITICAL: We shift by 1 before rolling to ensure that the current hour's
    # energy is NOT included in its own rolling mean (prevents lookahead data leakage).
    data["energy_rolling_mean_24h"] = data["energy"].shift(1).rolling(window=24, min_periods=1).mean()

    # 4. Handle initial NaNs caused by lagging
    if drop_na:
        # The first 24 rows will have NaN for energy_lag_24h
        initial_count = len(data)
        data.dropna(subset=FEATURE_COLUMNS, inplace=True)
        data.reset_index(drop=True, inplace=True)
        dropped_count = initial_count - len(data)
        # Note: Dropped first 24 warm-up rows

    return data


def time_based_train_test_split(
    df: pd.DataFrame,
    test_size: float = 0.20
) -> Tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series, List[str], pd.DataFrame, pd.DataFrame]:
    """
    Splits time-series data chronologically into train and test sets.

    WHY NOT RANDOM SPLIT?
    Random splitting (e.g. train_test_split with shuffle=True) causes severe "Data Leakage"
    in time-series problems. If the model is trained on hour 15 and tested on hour 14 of
    the same day, it learns from future observations to predict the past.
    A chronological split trains strictly on the past (first 80%) and evaluates strictly
    on the unseen future (last 20%), simulating how the Digital Twin operates in the real world.

    Parameters:
    -----------
    df : pd.DataFrame
        DataFrame with features and target.
    test_size : float
        Proportion of records to reserve for testing (e.g., 0.20 = 20%).

    Returns:
    --------
    X_train, y_train, X_test, y_test, feature_names, train_df, test_df
    """
    total_samples = len(df)
    split_index = int(total_samples * (1.0 - test_size))

    train_df = df.iloc[:split_index].copy()
    test_df = df.iloc[split_index:].copy()

    X_train = train_df[FEATURE_COLUMNS]
    y_train = train_df[TARGET_COLUMN]

    X_test = test_df[FEATURE_COLUMNS]
    y_test = test_df[TARGET_COLUMN]

    return X_train, y_train, X_test, y_test, FEATURE_COLUMNS, train_df, test_df


if __name__ == "__main__":
    from preprocess import load_or_generate_data, clean_data
    
    print("Testing features module...")
    raw = load_or_generate_data()
    clean = clean_data(raw)
    featured = create_features(clean)
    
    X_tr, y_tr, X_te, y_te, f_cols, tr_df, te_df = time_based_train_test_split(featured, 0.2)
    print(f"Total features: {len(f_cols)} -> {f_cols}")
    print(f"Train size: {len(X_tr)} records ({tr_df['timestamp'].min()} to {tr_df['timestamp'].max()})")
    print(f"Test size:  {len(X_te)} records ({te_df['timestamp'].min()} to {te_df['timestamp'].max()})")
